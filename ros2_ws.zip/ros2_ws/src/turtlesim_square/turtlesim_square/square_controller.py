import math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose


class SquareController(Node):
    def __init__(self):
        super().__init__('square_controller')
        self.publisher_ = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        self.subscription = self.create_subscription(Pose, '/turtle1/pose', self.pose_callback, 10)
        self.pose = None
        self.timer = self.create_timer(0.1, self.move_square)  # 10 Hz
        self.state = 'move_forward'
        self.target_distance = 2.0
        self.start_x = None
        self.start_y = None
        self.start_angle = None
        self.sides_completed = 0
        self.done = False

    def pose_callback(self, msg: Pose):
        self.pose = msg

    def stop_and_exit(self):
        twist = Twist()
        twist.linear.x = 0.0
        twist.angular.z = 0.0
        self.publisher_.publish(twist)
        self.timer.cancel()
        self.get_logger().info('Completed one square. Stopping controller.')
        self.destroy_node()

    def move_square(self):
        if self.pose is None or self.done:
            return

        twist = Twist()

        if self.state == 'move_forward':
            if self.start_x is None:
                self.start_x = self.pose.x
                self.start_y = self.pose.y

            dx = self.pose.x - self.start_x
            dy = self.pose.y - self.start_y
            distance = math.sqrt(dx * dx + dy * dy)

            if distance < self.target_distance:
                twist.linear.x = 1.0
                twist.angular.z = 0.0
            else:
                twist.linear.x = 0.0
                twist.angular.z = 0.0
                self.state = 'turn'
                self.start_angle = self.pose.theta

        elif self.state == 'turn':
            # Normalize delta angle to handle wrap-around
            dtheta = self.pose.theta - self.start_angle
            while dtheta > math.pi:
                dtheta -= 2 * math.pi
            while dtheta < -math.pi:
                dtheta += 2 * math.pi

            if abs(dtheta) < (math.pi / 2 ):
                twist.linear.x = 0.0
                twist.angular.z = 0.5
            else:
                twist.linear.x = 0.0
                twist.angular.z = 0.0
                self.state = 'move_forward'
                self.start_x = None
                self.start_y = None
                self.sides_completed += 1

                if self.sides_completed >= 4:
                    self.done = True
                    self.stop_and_exit()

        self.publisher_.publish(twist)


def main(args=None):
    rclpy.init(args=args)
    node = SquareController()
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == '__main__':
    main()

