#include <memory>
#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>


#include <cmath>
#include <vector>


std::vector<double> calculate_2dof_ik(double x, double y, double l1, double l2)
{
    std::vector<double> joints; // Create an empty vector to store the angles

    // 1. Calculate the cos(theta2) term
    double cos_t2 = (x * x + y * y - l1 * l1 - l2 * l2) / (2.0 * l1 * l2);

    // 2. Safety check: Ensure the target is physically reachable
    if (cos_t2 < -1.0 || cos_t2 > 1.0) {
        return joints; // Return the empty vector (size 0) to indicate failure
    }

    // 3. Calculate Theta 2 (Elbow-down configuration)
    double theta2 = std::acos(cos_t2);

    // 4. Calculate Theta 1 using std::atan2
    double term1 = std::atan2(y, x);
    double term2 = std::atan2(l2 * std::sin(theta2), l1 + l2 * std::cos(theta2));
    double theta1 = term1 - term2;

    // 5. Pack the angles into the vector and return it
    joints.push_back(theta1);
    joints.push_back(theta2);

    return joints;
}
int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);

    auto node = std::make_shared<rclcpp::Node>("control_node");
    rclcpp::executors::SingleThreadedExecutor executor;
    executor.add_node(node);
    auto spinner = std::thread([&executor]() { executor.spin(); });

    auto arm = moveit::planning_interface::MoveGroupInterface(node, "arm");
    arm.setMaxVelocityScalingFactor(0.4);
    arm.setMaxAccelerationScalingFactor(0.4);

    //auto gripper = moveit::planning_interface::MoveGroupInterface(node, "gripper");

    // // Named goal

    // arm.setStartStateToCurrentState();
    // arm.setNamedTarget("pose_1");
    
    // moveit::planning_interface::MoveGroupInterface::Plan plan1;
    // bool success1 = (arm.plan(plan1) == moveit::core::MoveItErrorCode::SUCCESS);

    // if (success1) {
    //     arm.execute(plan1);
    // }

    // arm.setStartStateToCurrentState();
    // arm.setNamedTarget("home");
    
    // moveit::planning_interface::MoveGroupInterface::Plan plan2;
    // bool success2 = (arm.plan(plan2) == moveit::core::MoveItErrorCode::SUCCESS);

    // if (success2) {
    //     arm.execute(plan2);
    // }*/

    // --------------------------------------------------------------------------------

    //joint goal
    std::vector<double> target_joints = calculate_2dof_ik(0.28284, 0.28284, 0.2, 0.2);
     std::vector<double> joints = { target_joints[0],target_joints[1] };

     arm.setStartStateToCurrentState();
     arm.setJointValueTarget(joints);

     moveit::planning_interface::MoveGroupInterface::Plan plan1;
     bool success1 = (arm.plan(plan1) == moveit::core::MoveItErrorCode::SUCCESS);

     if (success1) {
         arm.execute(plan1);
     }
           
    // --------------------------------------------------------------------------------

     //Pose Goal

 /*(
 arm.setStartStateToCurrentState();
arm.clearPoseTargets();
    geometry_msgs::msg::PoseStamped target_pose;
    target_pose.header.frame_id = "base_link";
target_pose.pose.position.x = 0.225;
target_pose.pose.position.y = 0.0;
target_pose.pose.position.z = 0.0075;
target_pose.pose.orientation.x = 0.0;
    target_pose.pose.orientation.y = 0.0;
    target_pose.pose.orientation.z = 0.0;
// neutral orientation (important)
target_pose.pose.orientation.w = 1.0;

arm.setPoseTarget(target_pose);

      // IMPORTANT

//arm.setPositionTarget(0.25,0 ,0.05 );
arm.setPlanningTime(5.0);
arm.setGoalTolerance(0.02);
    moveit::planning_interface::MoveGroupInterface::Plan plan1;
    bool success1 = (arm.plan(plan1) == moveit::core::MoveItErrorCode::SUCCESS);

    if (success1) {
        arm.execute(plan1);
    }*/
    // ===== POSITION TARGET (3DOF SAFE) =====
/*
arm.setStartStateToCurrentState();
arm.clearPoseTargets();

// ✅ Only position (NO orientation)
arm.setPositionTarget(0.45, 0.0, 0);

// ✅ Improve planning success
arm.setPlanningTime(5.0);
arm.setGoalTolerance(0.02);
arm.setMaxVelocityScalingFactor(0.5);
arm.setMaxAccelerationScalingFactor(0.5);

moveit::planning_interface::MoveGroupInterface::Plan plan1;

bool success1 = (arm.plan(plan1) == moveit::core::MoveItErrorCode::SUCCESS);

if (success1)
{
    RCLCPP_INFO(node->get_logger(), "Position plan success");
    arm.execute(plan1);
}
else
{
    RCLCPP_WARN(node->get_logger(), "Position plan failed");
}

    /* Cartesian Path

    std::vector<geometry_msgs::msg::Pose> waypoints;
    geometry_msgs::msg::Pose pose1 = arm.getCurrentPose().pose;
    pose1.position.z += -0.2;
    waypoints.push_back(pose1);
    geometry_msgs::msg::Pose pose2 = pose1;
    pose2.position.y += 0.2;
    waypoints.push_back(pose2); 
    geometry_msgs::msg::Pose pose3 = pose2;
    pose3.position.y += -0.2;
    pose3.position.z += 0.2;
    waypoints.push_back(pose3);

    moveit_msgs::msg::RobotTrajectory trajectory;

    double fraction = arm.computeCartesianPath(waypoints, 0.01,0.0, trajectory);

    if (fraction == 1) {
        arm.execute(trajectory);
    }
    // ===== CARTESIAN PATH (BEST FOR 3DOF) =====

std::vector<geometry_msgs::msg::Pose> waypoints;

geometry_msgs::msg::Pose pose1;
pose1.position.x = 0.4;
pose1.position.y = 0.0;
pose1.position.z = 0.3;
pose1.orientation.w = 1.0;

waypoints.push_back(pose1);

geometry_msgs::msg::Pose pose2 = pose1;
pose2.position.y += 0.2;
waypoints.push_back(pose2);

geometry_msgs::msg::Pose pose3 = pose2;
pose3.position.y -= 0.2;
pose3.position.z += 0.2;
waypoints.push_back(pose3);

moveit_msgs::msg::RobotTrajectory trajectory;

double fraction = arm.computeCartesianPath(
    waypoints,
    0.01,
    0.0,
    trajectory
);

if (fraction > 0.9)
{
    RCLCPP_INFO(node->get_logger(), "Cartesian path success");
    arm.execute(trajectory);
}
else
{
    RCLCPP_WARN(node->get_logger(), "Cartesian path failed: %.2f", fraction);
}*/

    rclcpp::shutdown();
    spinner.join();
    return 0;
}
