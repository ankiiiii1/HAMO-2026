#include <memory>
#include <vector>
#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>

using namespace std::chrono_literals;

int main(int argc, char* argv[])
{
  rclcpp::init(argc, argv);
  
  auto const node = std::make_shared<rclcpp::Node>(
    "simple_move_node",
    rclcpp::NodeOptions().automatically_declare_parameters_from_overrides(true)
  );

  auto const logger = rclcpp::get_logger("simple_move_node");

  // 1. Initialize MoveGroup (Make sure "arm" matches your SRDF name)
  using moveit::planning_interface::MoveGroupInterface;
  auto move_group = MoveGroupInterface(node, "arm");

  // --- CRITICAL SETTINGS FOR 3-DOF ARM ---
  move_group.setPlanningTime(10.0);
  move_group.setNumPlanningAttempts(10);
  
  // Magic line: Tells MoveIt to ignore orientation. 
  // 3-DOF arms physically cannot reach a point AND maintain an orientation.
  move_group.setGoalOrientationTolerance(3.14); 
  move_group.setGoalPositionTolerance(0.02); 

  // 2. Updated "Safe" Coordinates
  // These are closer to the base to ensure reachability.
  std::vector<std::vector<double>> points = {
    {0.5, 0, 0}, // Point 1
    //{0.15,  0.05, 0.15}, // Point 2
    //{0.18,  0.00, 0.10}  // Point 3
  };

  RCLCPP_INFO(logger, "Starting MoveIt sequence...");

  while (rclcpp::ok()) {
    for (size_t i = 0; i < points.size(); ++i) {
      double x = points[i][0];
      double y = points[i][1];
      double z = points[i][2];

      RCLCPP_INFO(logger, "Target %zu: [x: %.2f, y: %.2f, z: %.2f]", i + 1, x, y, z);

      // We use PositionTarget to focus only on the X,Y,Z coordinates
      move_group.setPositionTarget(x, y, z);

      moveit::planning_interface::MoveGroupInterface::Plan my_plan;
      bool success = (move_group.plan(my_plan) == moveit::core::MoveItErrorCode::SUCCESS);

      if (success) {
        RCLCPP_INFO(logger, "Plan found, executing...");
        move_group.execute(my_plan);
      } else {
        RCLCPP_ERROR(logger, "Plan FAILED. Is the point reachable? Is kinematics.yaml loaded?");
      }

      rclcpp::sleep_for(1s);
    }
  }

  rclcpp::shutdown();
  return 0;
}
